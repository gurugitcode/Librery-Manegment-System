# Librery-Manegment-System

# Librery-Manegment-System Required Tool and python package ~ Any Code Editer (python-IDLE, Visual Studio code ,pycharm,Atom)
 python3  <BR>
pip install django <br>
open terminal  <br>
cd /Project folder  <br>
Run command  <br>
python manage.py runserver  <br>
find this url <br>
copy url < http://127.0.0.1:8000/> and paste in browser  <br>
