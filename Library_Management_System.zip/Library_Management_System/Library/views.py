from django.shortcuts import render,HttpResponseRedirect,HttpResponse
from django.views import View
from django.contrib.auth.models import User ,Group
from django.contrib.auth.forms import PasswordResetForm,PasswordChangeForm
from . forms import SignUpForm ,LoginForm ,AddBookForm
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout,update_session_auth_hash
from django.core.paginator import Paginator
from . models import Library_Book
from django.http import JsonResponse
import cv2
import easygui
import mediapipe as mp
import time
# Create your views here.

class MainView(View):
    templates_name = "mainpage.html"
    def get(self,request):
        book=Library_Book.objects.order_by('?')
        paginator = Paginator(book, 8)  # Show 10 contacts per page.
        page_number = request.GET.get('page')
        page_obj1 = paginator.get_page(page_number)
        return render(request,self.templates_name,{"page_obj":page_obj1})


class User_Create(View):
    template_name = 'usersingup.html'
    def get(self,request):
        fm_data = SignUpForm()
        return render(request,self.template_name,{"form":fm_data})

    def post(self,request):
        if request.method =='POST':
            fm_data = SignUpForm(request.POST)
            if fm_data.is_valid():
                messages.success(request,'Congratulations You have become authot')
                user=fm_data.save()
                group = Group.objects.get_or_create(name="Author")
                group = Group.objects.get(name='Author')
                user.groups.add(group)
                fm_data =SignUpForm()
                messages.success(request,'Successfully Your Account Created.')
                print('Successfully Your Account Created')
        else:
            fm_data =SignUpForm()
        return render(request,self.template_name,{"form":fm_data})           

class UserLogin(View):
    template_name="Login.html"
    def get(self,request):
        fm=LoginForm()
        return render(request, self.template_name,{'form':fm})

    def post(self,request):
        if request.method=='POST':
            fm = LoginForm(request=request,data=request.POST)
            if fm.is_valid():
                uname = fm.cleaned_data['username']
                upass = fm.cleaned_data['password']
                user = authenticate(username=uname,password=upass)
                if user is not None:
                    login(request,user)
                    group = Group.objects.get(name='Author')
                    users = group.user_set.all()
                    return HttpResponseRedirect('/')
                else:
                    fm=LoginForm()
                    messages.success(request,'Unsuccessfully Your Login Account.')
                    return render(request, self.template_name,{'form':fm})
        else:
            fm=LoginForm()
        return render(request, self.template_name,{'form':fm})


#Logout_User
class User_logout(View):
    def get(self,request):
        if request.user.is_authenticated:
            logout(request)
            return HttpResponseRedirect('/')
        else:
            return HttpResponseRedirect('/')


class Add_Book(View):
    templates_name = "addbook.html"
    def get(self,request):
        forms=AddBookForm()
        return render(request,self.templates_name,{"fm":forms})
    
    def post(self,request):
        print('after Successfully Your Post Updated')
        if request.method=='POST':
            addimg = AddBookForm(request.POST, request.FILES)
            if addimg.is_valid():
                addimg.save()
                messages.success(request,'Successfully Your Post Uploaded.')
                print('Successfully Your Post Updated')
                addimg=AddBookForm()
                return render(request,self.templates_name,{'fm':addimg})
        return render(request,self.templates_name,{'fm':addimg})
 
# Create your Update Book views here.
class UpdateBookFinally(View):
    template_name = "updatebook.html"
    def get(self, request,serial_no):
        data = Library_Book.objects.get(pk=serial_no)
        addimg = AddBookForm(instance=data)
        return render(request,self.template_name,{'fm':addimg})

    def post(self,request,serial_no):
        if request.method=='POST':
            data = Library_Book.objects.get(pk=serial_no)
            addimg = AddBookForm(request.POST,instance=data)
            if addimg.is_valid():
                addimg.save()
                messages.success(request,'Successfully Your Post Updated.')
                return HttpResponseRedirect('/')
        return render(request,self.template_name,{'fm':addimg})   
# Create your Delete Book views here.
class DeleteBook(View):
    def get(self, request,serial_no):
        data = Library_Book.objects.get(pk=serial_no)
        data.delete()
        return HttpResponseRedirect('/')



class TakenImage(View):
    # None
    def get(self,request):
        cap = cv2.VideoCapture(0)
        mpHands = mp.solutions.hands
        hands = mpHands.Hands(static_image_mode=False,
                            max_num_hands=2,
                            min_detection_confidence=0.5,
                            min_tracking_confidence=0.5)
        mpDraw = mp.solutions.drawing_utils

        pTime = 0
        cTime = 0
        while True:
            success, img = cap.read()
            imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            results = hands.process(imgRGB)
            # print(results.multi_hand_landmarks)

            if results.multi_hand_landmarks:
                print(results.multi_hand_landmarks)
                if "None" in results.multi_hand_landmarks:
                    # break
                    # print(results)
                    
                    # time.sleep(2)
                    for handLms in results.multi_hand_landmarks:
                        for id, lm in enumerate(handLms.landmark):
                            #print(id,lm)
                            h, w, c = img.shape
                            cx, cy = int(lm.x *w), int(lm.y*h)
                            #if id ==0:
                            cv2.circle(img, (cx,cy), 3, (255,0,255), cv2.FILLED)

                        mpDraw.draw_landmarks(img, handLms, mpHands.HAND_CONNECTIONS)
               
                else:
                    easygui.msgbox("captured your hand","cv2","Closed Cam")
                    # break


            cTime = time.time()
            fps = 1/(cTime-pTime)
            pTime = cTime

            cv2.putText(img,str(int(fps)), (10,70), cv2.FONT_HERSHEY_PLAIN, 3, (255,0,255), 3)

            cv2.imshow("Image", img)
            cv2.waitKey(1)  

        return HttpResponseRedirect('/')
    
    
   
# class Add_Book_Api(View):
#     template_name="index.html"
#     def get(self,request):
#         return JsonResponse({"status":0})
    
    
#     def post(self,request):
#         # print(request.POST)
#         if request.method=='POST':
#             sr_no=request.POST["serial_number"]    
#             bookname=request.POST["book_name"] 
#             bookimage=request.FILES.POST["book_image"]    
#             print('succsessfully upload data')
#             reg=Library_Book(serial_number=sr_no,book_name=bookname,book_image=bookimage)
#             reg.save()
#             return JsonResponse({"status":"Save"})
#         else:
#             return JsonResponse({"status":0})
#         return JsonResponse({"status":0})
