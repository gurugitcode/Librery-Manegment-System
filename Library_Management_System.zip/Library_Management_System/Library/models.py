from django.db import models

# Create your models here.
class Library_Book(models.Model):
    serial_number=models.IntegerField()
    book_name=models.CharField(max_length=300)
    book_image=models.ImageField(upload_to='images',null=True,blank=True,default='Not Available')

