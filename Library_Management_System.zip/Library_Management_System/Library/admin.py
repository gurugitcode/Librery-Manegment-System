from django.contrib import admin
from . models import Library_Book
# Register your models here.

@admin.register(Library_Book)
class Library_BookAdmin(admin.ModelAdmin):
    list_display=['serial_number','book_name','book_image']
